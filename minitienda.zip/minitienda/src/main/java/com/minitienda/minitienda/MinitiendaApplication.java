package com.minitienda.minitienda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinitiendaApplication {

	public static void main(String[] args) {
		// Método para iniciar la aplicación Spring Boot
	SpringApplication.run(MinitiendaApplication.class, args);

	}

}
