package com.almacenlibros.almacenlibros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlmacenLibrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
