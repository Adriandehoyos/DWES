package com.almacenlibros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlmacenLibrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlmacenLibrosApplication.class, args);
	}

}
