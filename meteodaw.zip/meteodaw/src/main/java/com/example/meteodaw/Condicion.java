package com.example.meteodaw;

public enum Condicion {
    LLUVIA, SOLEADO, NUBLADO, TORMENTA, NIEVE, GRANIZO, GALERNA
}
