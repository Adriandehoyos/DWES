package gestionpistas.gestionpistas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionpistasApplicationTests {

	@Test
	void contextLoads() {
	}

}
